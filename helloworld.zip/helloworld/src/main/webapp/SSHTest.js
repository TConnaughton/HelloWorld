/**
 * Created by tconnaughton on 11/5/2015.
 */

function listFiles()
{
    var x = document.getElementById("uploadFiles");
    var txt = "";
    var i;

    if ('files' in x)
    {
        if (x.files.length == 0)
        {
            document.getElementById("logButton").disabled = true;
            txt = "Select one or more files.";
        }
        else
        {
            for (i = 0; i < x.files.length; i++)
            {
                var file = x.files[i];

                if ('name' in file)
                {
                    txt += "<strong>" + (i+1) + ". " + file.name + "</strong><br/>";
                }

                if ('size' in file)
                {
                    txt += "Size: " + file.size + " bytes <br/>";
                }

                document.getElementById("logButton").disabled = false;
            }
        }
    }
    else
    {
        if (x.value == "")
        {
            document.getElementById("logButton").disabled = true;
            txt += "Select one or more files.";
        }
        else
        {
            document.getElementById("logButton").disabled = true;
            txt += "The files property is not supported by your browser!";
            txt  += "<br/>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead.
        }
    }

    document.getElementById("fileList").innerHTML = txt;
}


function getLogs()
{
    document.getElementById("uploadFiles").disabled = true;

    //document.getElementById("logButton").disabled = true;

    document.getElementById("fileList").innerHTML = "Processing...";
}