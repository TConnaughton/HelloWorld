package com.tutorialspoint.test;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

import org.apache.commons.io.IOUtils;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.Part;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

/**
 * Created by tconnaughton on 10/20/2015.
 */
@ManagedBean(name = "sshBean")
@RequestScoped
@Path("/pdf")
public class SSHTest
{
    private String host = ""; // Hostname of the remote machine
    private String user = ""; // Username of ssh account on remote machine
    private String password = ""; // Password associated with your ssh account
    private String versionNo = "510"; //IRAPT FTP/EDI Version Number
    private String environment = ""; // 'Dev' or 'Test'
    private String userDirectory = "automation"; // ftp_working or edi_working sub-directory
    private String errorMessage = "";
    private List<Part> partFiles; // Collection of Parts (Files) from the JSF/XHTML
    private List<File> files = new ArrayList<File>(); // Collection of those same files as Java Files

    public void ftpToLogs() throws JSchException, InterruptedException, SftpException, IOException
    {
        if (getFileName(partFiles.get(0)).equals(""))
        {
            errorMessage = "ERROR: Please select a file to upload!";
            return;
        }

        JSch jsch = new JSch();

        Session session = null;
        ChannelSftp sftp = null;

        if (host.equals("commodore.caci-op.com"))
        {
            environment = "Test";
        }
        else if (host.equals("shrek.caci-op.com"))
        {
            environment = "Dev";
        }

        try
        {
            session = jsch.getSession(user, host, 22);

            session.setPassword(password);

            session.setConfig("StrictHostKeyChecking", "no");
            session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");

            // session.connect(); - ten second timeout
            session.connect(10 * 1000);
        }
        catch (JSchException exception)
        {
            errorMessage = "ERROR: Unable to connect to " + host + " with the specified username/password!";
            exception.printStackTrace(System.out);
        }


        if (session != null && session.isConnected()) {
            try
            {
                sftp = (ChannelSftp) session.openChannel("sftp");

                // channel.connect(); - fifteen second timeout
                sftp.connect(15 * 1000);
            }
            catch (JSchException exception)
            {
                errorMessage = "ERROR: Unable to open an SFTP channel on " + host + "!";
                exception.printStackTrace(System.out);
            }
        }


        if (sftp != null && sftp.isConnected())
        {
            try
            {
                String ymdString = "";
                ArrayList<SftpATTRS> importFileAttributes = new ArrayList<SftpATTRS>();
                ArrayList<String> logLocations = new ArrayList<String>();
                ArrayList<String> logNames = new ArrayList<String>();


                for (Part partFile : partFiles)
                {
                    try
                    {
                        String fileContent = "";
                        fileContent = new Scanner(partFile.getInputStream()).useDelimiter("\\A").next();

                        File file = new File(getFileName(partFile));
                        FileWriter fileWriter = new FileWriter(file);
                        fileWriter.write(fileContent);
                        fileWriter.flush();
                        fileWriter.close();
                        files.add(file);
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                }


                for (File file : files)
                {
                    String ftpEdi = "";

                    if (file.getName().toLowerCase().endsWith(".ftp") || file.getName().toLowerCase().endsWith(".ftp2") || file.getName().toLowerCase().endsWith(".ftp3")) {
                        //If FTP File, go to ftp_working directory
                        sftp.cd("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/ftp_working/" + userDirectory);
                        ftpEdi = "ftp";

                        //Get the location of the log file
                        if (file.getName().toLowerCase().endsWith(".ftp2"))
                        {
                            logLocations.add("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/ftp2logs");
                        }
                        else
                        {
                            logLocations.add("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/ftplogs");
                        }
                    }
                    else if (file.getName().endsWith(".856") || file.getName().endsWith(".857") || file.getName().endsWith(".810") ||
                            file.getName().endsWith(".811") || file.getName().endsWith(".821") || file.getName().endsWith(".824") ||
                            file.getName().endsWith(".861") || file.getName().endsWith(".864") || file.getName().toUpperCase().endsWith(".527R"))
                    {
                        //If EDI File, go to edi_working directory
                        sftp.cd("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/edi_working/" + userDirectory);
                        ftpEdi = "edi";

                        //Get the location of the log file
                        if (file.getName().toUpperCase().endsWith(".527R"))
                        {
                            logLocations.add("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/edi527logs");
                        }
                        else
                        {
                            logLocations.add("/caci_db/efp/WAWF_RA_sec/" + environment + "/Version" + versionNo + "/FTPEDIDirectory/edi" + file.getName().substring(file.getName().length() - 3, file.getName().length()) + "logs");
                        }
                    }
                    else
                    {
                        //If neither FTP nor EDI file, put the file in the user's home directory
                        sftp.cd(sftp.getHome());

                        //There will be no log file
                        logLocations.add("");
                    }

                    //Put your local file on the server
                    sftp.put(file.getAbsolutePath(), file.getName());

                    //Get the Attributes Object for the uploaded file (Used for its modified timestamp to find associated logs)
                    SftpATTRS attribute = sftp.lstat(file.getName());
                    importFileAttributes.add(attribute);

                    //Predict the log file name based on the modified time of the ftp/edi file
                    String[] namePieces = attribute.getMtimeString().split(" ");
                    ymdString = namePieces[5] + getMonthNo(namePieces[1]) + namePieces[2];

                    if (ftpEdi.length() > 0)
                    {
                        logNames.add(ftpEdi + "_proc_log." + ymdString);
                    }
                    else
                    {
                        logNames.add("");
                    }
                }


                //Wait for crons to run (based on System Property: ImportWaitTime)
                Thread.sleep(60 * 1000);


                //Create a desktop folder for the FTP/EDI
                File folder = new File("C:\\Users\\" + System.getProperty("user.name") + "\\Desktop\\" + ymdString + "_FTPEDILogs");

                if (!folder.exists())
                {
                    if (folder.mkdir())
                    {
                        System.out.println("Directory is created!");
                    }
                    else
                    {
                        System.out.println("Failed to create directory!");
                    }
                }


                //Go to each logLocation and search for files whose name matches the expected file name
                for (int i = 0; i < logLocations.size(); i++)
                {
                    String location = logLocations.get(i);

                    //If log location exists...
                    if (location.length() > 0) {
                        //Switch directory to that location
                        sftp.cd(location);

                        //Put each matching log filename in a temporary list
                        Vector<ChannelSftp.LsEntry> tempLogList = sftp.ls(logNames.get(i) + "*");
                        ArrayList<String> finalLogList = new ArrayList<String>();

                        for (ChannelSftp.LsEntry logFile : tempLogList)
                        {
                            //If log file was created after original file, add it to the final list
                            if (logFile.getAttrs().getMTime() > importFileAttributes.get(i).getMTime())
                            {
                                finalLogList.add(logFile.getFilename());
                            }
                        }

                        //If more than 1 potential log is returned, check the original file name in the log to verify.
                        if (finalLogList.size() > 1)
                        {
                            for (int j = 0; j < finalLogList.size(); j++)
                            {
                                //Turn log file into a string and split into lines
                                String fileString = IOUtils.toString(sftp.get(finalLogList.get(j)));
                                String[] lines = fileString.split("\\n");

                                //Go through lines looking for the Import File: line
                                for (String line : lines)
                                {
                                    if (line.startsWith("Import File: "))
                                    {
                                        //Get Import File Name
                                        String[] importFileLinePieces = line.split(": ");
                                        String importFileName = importFileLinePieces[1];

                                        //If Import File Name in the log matches one of the original files, put the log file into the folder on the desktop.
                                        if (importFileName.equals(files.get(i).getName()))
                                        {
                                            sftp.get(finalLogList.get(j), "C:\\Users\\" + System.getProperty("user.name") + "\\Desktop\\" + ymdString + "_FTPEDILogs");
                                            break;
                                        }

                                        break;
                                    }
                                }
                            }
                        }
                        //Else, if only 1 is returned, put that log file into the desktop folder
                        else if (finalLogList.size() == 1)
                        {
                            sftp.get(finalLogList.get(0), "C:\\Users\\" + System.getProperty("user.name") + "\\Desktop\\" + ymdString + "_FTPEDILogs");
                        }
                    }
                }
            }
            catch (SftpException sftpException)
            {
                errorMessage = "ERROR: Either " + host + " is down, or you entered an invalid version number!";
            }
            catch (Exception e)
            {
                errorMessage = "ERROR: An unexpected error occurred while processing the files!";
                e.printStackTrace(System.out);
            }

            // Disconnect (close connection, clean up system resources)
            sftp.disconnect();
        }

        if (session != null && session.isConnected())
        {
            session.disconnect();
        }
    }


    public static String getMonthNo(String monthString) {
        String monthNo = "";

        if (monthString.equals("Jan")) {
            monthNo = "01";
        } else if (monthString.equals("Feb")) {
            monthNo = "02";
        } else if (monthString.equals("Mar")) {
            monthNo = "03";
        } else if (monthString.equals("Apr")) {
            monthNo = "04";
        } else if (monthString.equals("May")) {
            monthNo = "05";
        } else if (monthString.equals("Jun")) {
            monthNo = "06";
        } else if (monthString.equals("Jul")) {
            monthNo = "07";
        } else if (monthString.equals("Aug")) {
            monthNo = "08";
        } else if (monthString.equals("Sep")) {
            monthNo = "09";
        } else if (monthString.equals("Oct")) {
            monthNo = "10";
        } else if (monthString.equals("Nov")) {
            monthNo = "11";
        } else if (monthString.equals("Dec")) {
            monthNo = "12";
        }

        return monthNo;
    }

    public static String getFileName(Part filePart)
    {
        String header = filePart.getHeader("content-disposition");

        for (String headerPart : header.split(";"))
        {
            if (headerPart.trim().startsWith("filename"))
            {
                return headerPart.substring(headerPart.indexOf('=') + 1).trim().replace("\"", "");
            }
        }

        return "";
    }


    public static void writeToTemplate()
    {
        String fileName = "C:\\JSF\\helloworld\\src\\main\\resources\\GFPAttachmentTemplate.xlsx";
        FileInputStream excelFile = null;

        try
        {
            excelFile = new FileInputStream(new File(fileName));
            XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
            XSSFCell cell;

            
            //TODO: <------------------------ CONTRACT INFO SECTION --------------------------------------------->
            XSSFSheet sheet = workbook.getSheetAt(0);

            //Attachment Number: Cell 5F
            cell = sheet.getRow(4).getCell(5);
            cell.setCellValue("5");

            //Attachment Date: Cell 5T
            cell = sheet.getRow(4).getCell(19);
            cell.setCellValue("2017-10-16");

            //Attachment File (before of): Cell 6F
            cell = sheet.getRow(5).getCell(5);
            cell.setCellValue("1");

            //Attachment File (after of): Cell 6H
            cell = sheet.getRow(5).getCell(7);
            cell.setCellValue("1");

            //Name: Cell 10E
            cell = sheet.getRow(9).getCell(4);
            cell.setCellValue("John Doe");

            //Email: Cell 10M
            cell = sheet.getRow(9).getCell(12);
            cell.setCellValue("john.doe@example.mil");

            //Phone: Cell 10T
            cell = sheet.getRow(9).getCell(19);
            cell.setCellValue("904-123-4567");

            //Contract Award: Cell 13F
            cell = sheet.getRow(12).getCell(5);
            cell.setCellValue(true);

            //Contract Mod: Cell 13J
            cell = sheet.getRow(12).getCell(9);

            //Solicitation: Cell 13R
            cell = sheet.getRow(12).getCell(17);

            //Amendment: Cell 13V
            cell = sheet.getRow(12).getCell(21);

            //Mod Number: Cell 14H
            cell = sheet.getRow(13).getCell(7);
            cell.setCellValue("2");

            //Amendment No: Cell 14T
            cell = sheet.getRow(13).getCell(19);
            cell.setCellValue("2");

            //SCorUPN - Issuing Office DoDAAC: Cell 23C
            cell = sheet.getRow(22).getCell(2);
            cell.setCellValue("FU4417");

            //SCorUPN - Issuing Year: Cell 23E
            cell = sheet.getRow(22).getCell(4);
            cell.setCellValue("17");

            //SCorUPN - Contract Type: Cell 23G
            cell = sheet.getRow(22).getCell(6);
            cell.setCellValue("D");

            //SCorUPN - Sequence Number: Cell 23I
            cell = sheet.getRow(22).getCell(8);
            cell.setCellValue("AB12");

            //Order Number - Issuing Office DoDAAC: Cell 23M
            cell = sheet.getRow(22).getCell(12);
            cell.setCellValue("FU4417");

            //Order Number - Issuing Year: Cell 23O
            cell = sheet.getRow(22).getCell(14);
            cell.setCellValue("17");

            //Order Number - Contract Type: Cell 23Q
            cell = sheet.getRow(22).getCell(16);
            cell.setCellValue("F");

            //Order Number - Sequence Number: Cell 23S
            cell = sheet.getRow(22).getCell(18);
            cell.setCellValue("ABCD");

            //Order Number - "OLD" FORMAT: Cell 23V
            cell = sheet.getRow(22).getCell(21);
            cell.setCellValue("1234");


            //TODO: <------------------------ SERIALLY MANAGED ITEMS --------------------------------------------->
            sheet = workbook.getSheetAt(1);

            //Line Number: Cell 6B
            cell = sheet.getRow(5).getCell(1);
            cell.setCellValue("1");

            //Item Name: Cell 6C
            cell = sheet.getRow(5).getCell(2);
            cell.setCellValue("Item Name");

            //Item Description: Cell 6D
            cell = sheet.getRow(5).getCell(3);
            cell.setCellValue("Item Description");

            //NSN: Cell 6E
            cell = sheet.getRow(5).getCell(4);
            cell.setCellValue("1234567890123");

            //MFR CAGE: Cell 6F
            cell = sheet.getRow(5).getCell(5);
            cell.setCellValue("0HC11");

            //PART NUMBER: Cell 6G
            cell = sheet.getRow(5).getCell(6);
            cell.setCellValue("PN1234");

            //MODEL NUMBER: Cell 6H
            cell = sheet.getRow(5).getCell(7);
            cell.setCellValue("MN1234");

            //QTY: Cell 6K
            cell = sheet.getRow(5).getCell(10);
            cell.setCellValue("10");

            //UNIT OF MEASURE: Cell 6L
            cell = sheet.getRow(5).getCell(11);
            cell.setCellValue("100 Kilograms");

            //UNIT ACQ COST: Cell 6M
            cell = sheet.getRow(5).getCell(12);
            cell.setCellValue("20");

            //USE AS-IS: Cell 6N
            cell = sheet.getRow(5).getCell(13);
            cell.setCellValue("true");

            //DELIVERY DATE: Cell 6O

            //DURATION: Cell 6P
            cell = sheet.getRow(5).getCell(15);
            cell.setCellValue("4");

            //TIME UNIT: Cell 6Q
            cell = sheet.getRow(5).getCell(16);
            cell.setCellValue("Months");

            //DELIVERY EVENT: Cell 6R
            cell = sheet.getRow(5).getCell(17);
            cell.setCellValue("Award Date");

            //NOTES: Cell 6S
            cell = sheet.getRow(5).getCell(18);
            cell.setCellValue("Notes");


            //TODO: <------------------------ NON-SERIALLY MANAGED ITEMS --------------------------------------------->
            sheet = workbook.getSheetAt(2);

            //Line Number: Cell 6B
            cell = sheet.getRow(5).getCell(1);
            cell.setCellValue("2");

            //Item Name: Cell 6C
            cell = sheet.getRow(5).getCell(2);
            cell.setCellValue("Item Name");

            //Item Description: Cell 6D
            cell = sheet.getRow(5).getCell(3);
            cell.setCellValue("Item Description");

            //NSN: Cell 6E
            cell = sheet.getRow(5).getCell(4);
            cell.setCellValue("1234567890123");

            //MFR CAGE: Cell 6F
            cell = sheet.getRow(5).getCell(5);
            cell.setCellValue("0HC11");

            //PART NUMBER: Cell 6G
            cell = sheet.getRow(5).getCell(6);
            cell.setCellValue("PN1234");

            //MODEL NUMBER: Cell 6H
            cell = sheet.getRow(5).getCell(7);
            cell.setCellValue("MN1234");

            //QTY: Cell 6I
            cell = sheet.getRow(5).getCell(8);
            cell.setCellValue("10");

            //UNIT OF MEASURE: Cell 6J
            cell = sheet.getRow(5).getCell(9);
            cell.setCellValue("100 Kilograms");

            //UNIT ACQ COST: Cell 6K
            cell = sheet.getRow(5).getCell(10);
            cell.setCellValue("20");

            //USE AS-IS: Cell 6L
            cell = sheet.getRow(5).getCell(11);
            cell.setCellValue("true");

            //DELIVERY DATE: Cell 6M
            cell = sheet.getRow(5).getCell(12);
            cell.setCellValue("2017-10-01");

            //DURATION: Cell 6N

            //TIME UNIT: Cell 6O

            //DELIVERY EVENT: Cell 6P

            //NOTES: Cell 6Q
            cell = sheet.getRow(5).getCell(16);
            cell.setCellValue("Notes");


            //TODO: <------------------------ REQUISITION --------------------------------------------->
            sheet = workbook.getSheetAt(3);

            //Line Number: Cell 6D
            cell = sheet.getRow(5).getCell(3);
            cell.setCellValue("3");

            //Item Name: Cell 6E
            cell = sheet.getRow(5).getCell(4);
            cell.setCellValue("Item Name");

            //Item Description: Cell 6F
            cell = sheet.getRow(5).getCell(5);
            cell.setCellValue("Item Description");

            //NSN: Cell 6G
            cell = sheet.getRow(5).getCell(6);
            cell.setCellValue("1234567890123");

            //MFR CAGE: Cell 6H
            cell = sheet.getRow(5).getCell(7);
            cell.setCellValue("0HC11");

            //PART NUMBER: Cell 6I
            cell = sheet.getRow(5).getCell(8);
            cell.setCellValue("PN1234");

            //QTY: Cell 6J
            cell = sheet.getRow(5).getCell(9);
            cell.setCellValue("10");

            //UNIT OF MEASURE: Cell 6K
            cell = sheet.getRow(5).getCell(10);
            cell.setCellValue("100 Kilograms");

            //UNIT ACQ COST: Cell 6L
            cell = sheet.getRow(5).getCell(11);
            cell.setCellValue("20");

            //USE AS-IS: Cell 6M
            cell = sheet.getRow(5).getCell(12);
            cell.setCellValue("true");

            excelFile.close();

            FacesContext facesContext = FacesContext.getCurrentInstance();
            ExternalContext externalContext = facesContext.getExternalContext();
            externalContext.setResponseContentType("application/vnd.ms-excel");
            externalContext.setResponseHeader("Content-Disposition", "attachment; filename=\"gfpAttachmentExport.xlsx\"");

            workbook.write(externalContext.getResponseOutputStream());
            facesContext.responseComplete();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @GET
    @Path("/get")
    @Produces({"application/xml", "application/json"})
    public Response getFile(@QueryParam("contractNo") String contractNo, @QueryParam("orderNo") String orderNo, @QueryParam("modNo") String modNo, @QueryParam("attachNo") String attachNo)
    {
        ResponseBuilder response;
        System.out.println("The PDF has been returned for Contract: " + contractNo + ", Order: " + orderNo + ", Modification: " + modNo);

        if(attachNo != null)
        {
            File file = new File("C:\\JSF\\helloworld\\src\\main\\resources\\SampleXML.xml");

            response = Response.ok(file);
            response.header("Content-Disposition", "attachment; filename=solicitationResponse.xml");
            return response.build();
        }

        response = Response.ok("{" + getResponseStatus(Response.Status.OK) + getResponseMessages() +
                        getResponseResult(contractNo, orderNo, modNo) + "\n}",
                        MediaType.APPLICATION_JSON_TYPE);
        return response.build();
    }


    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(String versionNo) {
        this.versionNo = versionNo;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public List<Part> getPartFiles() {
        return partFiles;
    }

    public void setPartFiles(List<Part> partFiles) {
        this.partFiles = partFiles;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getResponseStatus(Response.Status status)
    {
        return "\n\tStatus: '" + status.toString() + "'\n\tCode: '" + status.getStatusCode() + "'";
    }

    public String getResponseMessages()
    {
        return "\n\tMessages: []";
    }

    public String getResponseResult(String contractNo, String orderNo, String modNo)
    {
        StringBuilder sb = new StringBuilder();

        sb.append("\n\tResult: \n\t{");

        sb.append("\n\t\tcontractNo: '").append(contractNo).append("'");
        sb.append("\n\t\torderNo: '").append(orderNo).append("'");
        sb.append("\n\t\tmodNo: '").append(modNo).append("'");

        sb.append("\n\t\tattachments: ").append("\n\t\t[");
        sb.append("\n\t\t\t{ number: '1', date: '2017-05-12' }");
        sb.append("\n\t\t\t{ number: '4', date: '2017-09-23' }");
        sb.append("\n\t\t]");

        sb.append("\n\t}");

        return sb.toString();
    }
}